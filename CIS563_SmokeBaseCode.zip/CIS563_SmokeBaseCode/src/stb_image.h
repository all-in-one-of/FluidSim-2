#ifndef STB_IMAGE_H
#define STB_IMAGE_H

#define STBI_HEADER_FILE_ONLY
#include "stb_image.c"

#endif // STB_IMAGE_H